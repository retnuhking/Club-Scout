package org.cate.hunterking.clubscheduler

val dayArray = arrayOf("Sat", "Sun", "Mon", "Tue", "Wed", "Thu", "Fri")

//For converting month integers to strings in the UI
val monthArray = arrayOf(
    "January", "February", "March", "April", "May",
    "June", "July", "August", "September", "October", "November", "December"
)

class ScheduleViewModel {

    val eventArray = mutableListOf<Event>()

    val subscribedArray = mutableListOf<String>()

    val availableNotificationIds = arrayOf(R.id.notification_id_1, R.id.notification_id_2, R.id.notification_id_3,
        R.id.notification_id_4, R.id.notification_id_5,
        R.id.notification_id_6, R.id.notification_id_7,
        R.id.notification_id_8, R.id.notification_id_9)
}