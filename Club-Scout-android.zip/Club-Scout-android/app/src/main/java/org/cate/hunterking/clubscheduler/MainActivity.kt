package org.cate.hunterking.clubscheduler


import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v4.app.NotificationCompat
import android.support.v4.app.NotificationManagerCompat
import android.support.v7.app.AppCompatActivity
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuInflater
import android.view.View
import android.widget.CheckBox
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.club_checkbox_layout.view.*
import kotlinx.android.synthetic.main.new_event_layout.view.*
import org.jetbrains.anko.forEachChild
import java.sql.Time
class MainActivity : AppCompatActivity() {

    private lateinit var viewModel: ScheduleViewModel

    private val CHANNEL_ID = "schedule_channel_id"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        viewModel = ScheduleViewModel()
        createNotificationChannel()

        val res = resources

        //Initialize bottom navigation
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)

        //Initialize button that starts NewEventActivity to get data for a new club event
        addEventButton.setOnClickListener{
            val mIntent = Intent(this, NewEventActivity::class.java)
            startActivityForResult(mIntent, 1337)
        }

        //Inflate "subscribe" check boxes for every club in the subscriptions tab
        val clubNameArray = res.getStringArray(R.array.club_array)
        for (club in clubNameArray){
            val clubCheckBoxLayout = LayoutInflater.from(applicationContext).inflate(R.layout.club_checkbox_layout, null)
            val clubCheckBox = clubCheckBoxLayout.subCB
            clubCheckBox.text = club
            clubCheckBox.setOnCheckedChangeListener { _, isChecked ->  subCheckBoxMethods(isChecked, clubCheckBox)}

            subscriptionsLayout.addView(clubCheckBoxLayout)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = MenuInflater(applicationContext)
        inflater.inflate(R.menu.menu_refresh, menu)
        return true
    }

    //Display the new event with data received from the NewEventActivity fields
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1337 && resultCode == RESULT_OK){
            val newEvent = data!!.getParcelableExtra<Event>("EVENT")
            addEvent(newEvent)
            viewModel.eventArray.plus(newEvent)
        }
    }

    private fun addEvent(event: Event){
        //Load template layout
        val eventLayout = LayoutInflater.from(applicationContext).inflate(R.layout.new_event_layout, null)
        val eventNotificationId = viewModel.availableNotificationIds.first()

        //Fill layout with data
        eventLayout.clubNameTV.text = event.clubName
        eventLayout.eDescTV.text = event.meetingDesc
        eventLayout.locationTV.text = event.location

        //Special case scenarios for time formatting
        val newTime = Time(event.dateTime)
        val amPm: String
        val pmMath: Int
        if (newTime.hours > 12) {
            amPm = " PM"
            pmMath = 12
        } else if (newTime.hours == 12){
            amPm = " PM"
            pmMath = 0
        } else {
            amPm = " AM"
            pmMath = 0
        }
        val minuteFormatter: String
        if (newTime.minutes < 10){
            minuteFormatter = "0"
        } else {
            minuteFormatter = ""
        }
        val newTimeString = (newTime.hours - pmMath).toString() + ":" + minuteFormatter + newTime.minutes.toString() + amPm
        eventLayout.timeTV.setText(newTimeString)

        scrollLayout.addView(eventLayout)
        scrollLayout.visibility = View.VISIBLE

        //Initialize notification builder with parameters for Event notification
        val builder = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_today_black_24dp)
            .setContentTitle(event.clubName)
            .setContentText(event.meetingDesc + " in " + event.location + " at " + newTimeString)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        //Define methods for event checkbox (show a notification when checked, remove when unchecked)
        eventLayout.checkBox.setOnCheckedChangeListener{ buttonView, isChecked ->
            if (isChecked) {
                with(NotificationManagerCompat.from(this)) {
                    // notificationId is a unique int for each notification
                    notify(eventNotificationId, builder.build())
                }
            } else {
                val notificationManager: NotificationManager =
                    getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.cancel(eventNotificationId)
            }
        }

        //Remove the first notification id from the array such that the next notification has a unique id
        viewModel.availableNotificationIds.drop(0)
    }

    private fun createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val name = "notification_channel"
            val descriptionText = "notification"
            val importance = NotificationManager.IMPORTANCE_DEFAULT
            val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
                description = descriptionText
            }
            // Register the channel with the system
            val notificationManager: NotificationManager =
                getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            notificationManager.createNotificationChannel(channel)
        }
    }

    //Define method for when a "subscribe to club" CheckBox is checked
    private fun subCheckBoxMethods(isChecked: Boolean, cb: CheckBox){
        if (isChecked) {
            cb.setButtonDrawable(R.drawable.ic_star_black_30dp)
            viewModel.subscribedArray.plus(cb.text.toString())

            //Check all check boxes for every event for given club
            scrollLayout.forEachChild{
                if (it.clubNameTV.text.toString() == cb.text.toString()){
                    it.checkBox.isChecked = true
                }
            }

            Toast.makeText(this, "Subscribed to " + cb.text.toString(), Toast.LENGTH_SHORT).show()

        } else if (!isChecked) {
            cb.setButtonDrawable(R.drawable.ic_star_border_black_30dp)
            viewModel.subscribedArray.remove(cb.text.toString())

            //Uncheck all check boxes for every event for given club
            scrollLayout.forEachChild{
                if (it.clubNameTV.text.toString() == cb.text.toString()){
                    it.checkBox.isChecked = false
                }
            }

            Toast.makeText(this, "Unsubscribed from " + cb.text.toString(), Toast.LENGTH_SHORT).show()
        }
    }

    //Set actions when bottom navigation items are selected
    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_feed -> {
                feedSV.visibility = View.VISIBLE
                subsSV.visibility = View.GONE

                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_subscriptions -> {
                feedSV.visibility = View.GONE
                subsSV.visibility = View.VISIBLE

                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }
}

