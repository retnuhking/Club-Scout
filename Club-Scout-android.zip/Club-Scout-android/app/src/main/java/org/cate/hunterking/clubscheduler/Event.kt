package org.cate.hunterking.clubscheduler

import android.arch.persistence.room.ColumnInfo
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.os.Parcel
import android.os.Parcelable

@Entity(tableName = "event_table")
data class Event(
    @PrimaryKey val eid: Int,
    @ColumnInfo(name = "club_name") val clubName: String?,
    @ColumnInfo(name = "meeting_desc") val meetingDesc: String?,
    @ColumnInfo(name = "location") val location: String?,
    @ColumnInfo(name = "date_time") val dateTime: Long
) : Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString(),
        parcel.readString(),
        parcel.readString(),
        parcel.readLong()
    )

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt(eid)
        parcel.writeString(clubName)
        parcel.writeString(meetingDesc)
        parcel.writeString(location)
        parcel.writeLong(dateTime)
    }
    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Event> {
        override fun createFromParcel(parcel: Parcel): Event {
            return Event(parcel)
        }

        override fun newArray(size: Int): Array<Event?> {
            return arrayOfNulls(size)
        }
    }
}