package org.cate.hunterking.clubscheduler

import android.arch.lifecycle.LiveData
import android.arch.persistence.room.Dao
import android.arch.persistence.room.Delete
import android.arch.persistence.room.Insert
import android.arch.persistence.room.Query

@Dao
interface EventDao {
    @Query("SELECT * FROM event_table")
    fun getAll(): LiveData<List<Event>>

    @Query("SELECT * FROM event_table WHERE eid IN (:eventIds)")
    fun loadAllByIds(eventIds: IntArray): List<Event>

    @Query("SELECT * FROM event_table WHERE club_name LIKE :club LIMIT 1")
    fun findByName(club: String): Event

    @Insert
    fun insertAll(vararg events: Event)

    @Delete
    fun delete(event: Event)
}