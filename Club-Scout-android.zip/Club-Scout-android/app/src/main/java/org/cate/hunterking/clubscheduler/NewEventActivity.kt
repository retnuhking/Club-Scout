package org.cate.hunterking.clubscheduler

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_new_event.*
import java.sql.Time
import java.util.*

class NewEventActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_event)

        val spinner: Spinner = findViewById(R.id.clubSpinner)
        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter.createFromResource(
            this,
            R.array.club_array,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            // Specify the layout to use when the list of choices appears
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Apply the adapter to the spinner
            spinner.adapter = adapter
        }

        var chosenClub = "N/A"
        //Set spinner methods
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent: AdapterView<*>?) {
                chosenClub = "INVALID"
            }

            //Store selected club as a variable to be sent when returning to MainActivity
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                chosenClub = parent!!.getItemAtPosition(position).toString()
            }
        }

        val c = Calendar.getInstance()
        val currentYear = c.get(Calendar.YEAR)
        val currentMonth = c.get(Calendar.MONTH)
        val currentDay = c.get(Calendar.DAY_OF_MONTH)

        var chosenDate = Date(currentYear, currentMonth, currentDay)
        val dpd = DatePickerDialog(this, DatePickerDialog.OnDateSetListener { _, chosenYear, chosenMonth, chosenDay ->

            // Display Selected date in date EditText
            chosenDate = Date(chosenYear, chosenMonth, chosenDay)
            dateET.setText(dayArray[chosenDate.day] + ", " + monthArray[chosenMonth] + " " + chosenDay)

        }, currentYear, currentMonth, currentDay)

        //Inflate datepickerdialogue when date edit text is selected
        dateET.setOnClickListener {
            dpd.show()
        }

        val currentHour = c.get(Calendar.HOUR)
        val currentMinute = c.get(Calendar.MINUTE)
        val currentSecond = c.get(Calendar.SECOND)

        //Initialize chosenTime variable to be set with values from timepickerdialogue
        var chosenTime = Time(currentHour, currentMinute, currentSecond)
        val tpd = TimePickerDialog(this,TimePickerDialog.OnTimeSetListener(function = { view, chosenHour, chosenMinute ->

            chosenTime = Time(chosenHour, chosenMinute, 0)

            //Special case scenarios for formatting the time into readable text
            val amPm: String
            val pmMath: Int
            if (chosenHour > 12) {
                amPm = " PM"
                pmMath = 12
            } else if (chosenHour == 12){
                amPm = " PM"
                pmMath = 0
            } else {
                amPm = " AM"
                pmMath = 0
            }
            val minuteFormatter: String
            if (chosenMinute < 10){
                minuteFormatter = "0"
            } else {
                minuteFormatter = ""
            }
            //Display selected time in time EditText
            timeET.setText((chosenHour - pmMath).toString() + ":" + minuteFormatter + chosenMinute.toString() + amPm)

        }),currentHour,currentMinute,false)

        //Inflate timepickerdialogue when time edittext is selected
        timeET.setOnClickListener {
            tpd.show()
        }

        //Return to home screen with the data from all the fields on "check" button press
        floatingActionButton.setOnClickListener{
            //Cannot exit activity if a field is blank
            if (timeET.text.isNotBlank() && dateET.text.isNotBlank() &&
                eventDescET.text.isNotBlank()){

                val returnIntent = Intent()

                //Format chosen times and date into one value (milliseconds since 1970)
                val newTime = Date(chosenDate.year,chosenDate.month,chosenDate.date,chosenTime.hours,chosenTime.minutes, chosenTime.seconds).time

                //Set Event data to send back to MainActivity
                val newEvent = Event(R.id.event_id, chosenClub, eventDescET.text.toString(), locationET.text.toString(),
                    newTime)

                returnIntent.putExtra("EVENT", newEvent)
                setResult(RESULT_OK, returnIntent)

                finish()
            } else {
                Toast.makeText(this, "Please fill out all the fields", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

