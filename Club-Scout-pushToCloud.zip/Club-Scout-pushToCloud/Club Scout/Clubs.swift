//
//  Clubs.swift
//  Club Scout
//
//  Created by cate on 4/16/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import Foundation

class MyVariables {
    
    var subscribedClubs = ["Math Modeling Club", "The Guilds", "ASU"]
    var allClubs = ["Business Club", "Book, Club", "Ricky", "Round Square", "BSU", "ASU", "Stream Team", "Math Modeling Club", "Math Olympics Club", "The Guilds"]
    
}
