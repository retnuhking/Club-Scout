//
//  SecondViewController.swift
//  Club Scout
//
//  Created by cate on 4/2/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData

class SecondViewController: UITableViewController {
 
    var clubArray = [Club]()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
 
    override func viewDidLoad() {
        super.viewDidLoad()
        
        loadItems()
        
    }
    
    var array : [String?] = []
    
    override func viewWillAppear(_ animated: Bool) {
        loadItems()
        tableView.reloadData()
        for club in clubArray {
            if club.subscribed == true {
                array.append(club.title)
            }
        }
    }
    
    func loadItems() {
        let request : NSFetchRequest<Club> = Club.fetchRequest()
        do {
            clubArray = try context.fetch(request)
        } catch {
            print("error fetching data from context \(error)")
        }
    }
    
    @IBOutlet weak var clubsTableView: UITableView!
    
    var selectedClubs : [String] = []

    let moreItems = MyVariables()
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var count = 0
        for club in clubArray {
            if club.subscribed == true {
                count += 1
            }
        }
        print("count is \(count)")
        return(count)
    }
    
    var count = 0
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? SubscribedCells
        cell?.cellDelegate = self
        cell?.labelName.text = array[count]
        cell?.buttonName.setTitle("Subscribed", for: .normal)
        cell?.index = indexPath
        count += 1
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.row == moreItems.subscribedClubs.count {
            performSegue(withIdentifier: "sendDataForwards", sender: self)
            
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "sendDataForwards" {
            let SecondSecondVC = segue.destination as! SecondSecondViewController
            SecondSecondVC.data = selectedClubs
        }
    }
    
    func dataReceived(data: String) {
        moreItems.subscribedClubs.append(data)
        
        tableView.beginUpdates()
        tableView.insertRows(at: [IndexPath(row: moreItems.subscribedClubs.count - 1, section: 0)], with: .automatic)
        tableView.endUpdates()
    }
    
}


extension SecondViewController: TableViewPassData {
    
    func onClickButton(index: Int) {
        self.tableView.deleteRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
    }
    
}

