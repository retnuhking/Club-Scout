//
//  FirstSecondViewController.swift
//  Club Scout
//
//  Created by cate on 4/27/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData

class FirstSecondViewController: UIViewController {

     let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    @IBOutlet weak var clubName: UITextField!
    @IBOutlet weak var mtngDescription: UITextField!
    @IBOutlet weak var location: UITextField!
    @IBOutlet weak var date: UITextField!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    //private var datePicker: UIDatePicker?
    
    var club = Club()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        datePicker.isHidden = true
        /*
        datePicker = UIDatePicker()
        datePicker?.datePickerMode = .dateAndTime
        datePicker?.addTarget(self, action: #selector(FirstSecondViewController.dateChanged(datePicker:)), for: .valueChanged)
        
        date.inputView = datePicker
        */
        // Do any additional setup after loading the view.
        clubName.placeholder = "Club Name"
        mtngDescription.placeholder = "Meeting description"
        location.placeholder = "Location"
        date.placeholder = "Time"
    }
    
    @IBAction func dateTextField(_ sender: UITextField) {
        
        datePicker.isHidden = false
        
        
    }
    
    @IBAction func dateTextFieldFinishedEditing(_ sender: UITextField) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE MMM d yyyy hh:mm"
        
        date.text = dateFormatter.string(from: datePicker.date)
        
    }
    
    
    @IBAction func uploadToCloud(_ sender: UIButton) {
        
        
        
    }
    
    
    
    
    /*
    @objc func dateChanged(datePicker: UIDatePicker) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE MMM d yyyy hh:mm"
        view.endEditing(true)
        
        date.text = dateFormatter.string(from: datePicker.date)
        //club.post_when = dateFormatter.string(from: datePicker.date)
    }
 */
    
    func saveContext() {
        do {
            try context.save()
        } catch {
            print("error saving context \(error)")
        }
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
