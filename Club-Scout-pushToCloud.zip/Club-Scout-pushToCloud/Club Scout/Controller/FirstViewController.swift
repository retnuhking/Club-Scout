//
//  FirstViewController.swift
//  Club Scout
//
//  Created by cate on 4/2/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

