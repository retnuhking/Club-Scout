//
//  SecondSecondViewController.swift
//  Club Scout
//
//  Created by cate on 4/3/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData

class SecondSecondViewController: UITableViewController {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var clubArray = [Club]()
    
    @IBOutlet weak var allClubsTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        allClubsTableView.delegate = self
        allClubsTableView.dataSource = self

        //loading clubs
        /*
        let allClubs = ["Business Club", "Book, Club", "Ricky", "Round Square", "BSU", "ASU", "Stream Team", "Math Modeling Club", "Math Olympics Club", "The Guilds"]
        for clubName in allClubs {
            let club = Club(context: context)
            club.title = clubName
            club.subscribed = false
            saveContext()
        }
        */
        loadItems()
    }
    
    func saveContext() {
        do {
            try context.save()
        } catch {
            print("error saving context \(error)")
        }
        self.tableView.reloadData()
    }
    
    func loadItems() {
        let request : NSFetchRequest<Club> = Club.fetchRequest()
        do {
            clubArray = try context.fetch(request)
        } catch {
            print("error fetching data from context \(error)")
        }
    }
    
    var data : [String] = []
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return(clubArray.count)
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? AllClubs
        if clubArray[indexPath.row].subscribed == false {
            cell?.buttonName.setTitle("Subscribe", for: .normal)
        } else {
            cell?.buttonName.setTitle("Unsubscribe", for: .normal)
        }
        cell?.clubName.text = clubArray[indexPath.row].title
        cell?.index = indexPath
        return cell!
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

/*
extension SecondSecondViewController: PassDataToSubscribedCells {
    
    func onTapSubscribeButton(index: Int) {
        //print("\(clubs.allClubs[index]) is clicked")
        //clubs.subscribedClubs.append(clubs.allClubs[index])
        //print(clubs.subscribedClubs)
        //delegate?.dataReceived(data: clubs.allClubs[index])
    }
    
}
*/
