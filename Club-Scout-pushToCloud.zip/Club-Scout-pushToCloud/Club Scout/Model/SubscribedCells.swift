//
//  SubscribedCells.swift
//  Club Scout
//
//  Created by cate on 4/15/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData


protocol TableViewPassData {
    func onClickButton(index: Int)
}


class SubscribedCells: UITableViewCell {
    
    var cellDelegate: TableViewPassData?
    
    var index: IndexPath?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var clubArray = [Club]()
    
    override func awakeFromNib() {
        super.awakeFromNib()

        loadItems()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func loadItems() {
        let request : NSFetchRequest<Club> = Club.fetchRequest()
        do {
            clubArray = try context.fetch(request)
        } catch {
            print("error fetching data from context \(error)")
        }
    }
    
    func saveContext() {
        do {
            try context.save()
        } catch {
            print("error saving context \(error)")
        }
    }
    
    @IBOutlet weak var labelName: UILabel!
    
    
    @IBOutlet weak var buttonName: UIButton!
    
    @IBAction func subscribed(_ sender: UIButton) {
        buttonName.setTitle("Unsubscribed", for: .normal)
        for club in clubArray {
            if club.title == labelName.text {
                club.subscribed = false
                saveContext()
            }
        }
        cellDelegate?.onClickButton(index: index!.row)
    }
    
}
