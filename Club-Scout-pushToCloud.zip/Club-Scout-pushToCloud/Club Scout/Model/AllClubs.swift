//
//  AllClubs.swift
//  Club Scout
//
//  Created by cate on 4/16/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData

class AllClubs: UITableViewCell {
    
    var index: IndexPath?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var clubArray = [Club]()
    
    @IBOutlet weak var clubName: UILabel!
    
    @IBOutlet weak var buttonName: UIButton!
    
    @IBAction func subUnsub(_ sender: Any) {
        if clubArray[(index?.row)!].subscribed == false {
            clubArray[(index?.row)!].subscribed = true
            buttonName.setTitle("Subscribed", for: .normal)
        } else {
            clubArray[(index?.row)!].subscribed = false
            buttonName.setTitle("Unsubscribed", for: .normal)
        }
        saveContext()
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()

        loadItems()
        
    }

    func loadItems() {
        let request : NSFetchRequest<Club> = Club.fetchRequest()
        do {
            clubArray = try context.fetch(request)
        } catch {
            print("error fetching data from context \(error)")
        }
    }
    
    func saveContext() {
        do {
            try context.save()
        } catch {
            print("error saving context \(error)")
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
}
