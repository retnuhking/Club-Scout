//
//  SubscribedCells.swift
//  Club Scout
//
//  Created by cate on 4/15/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData //The entity used is "Club"

//setting up for passing data between segues.
protocol TableViewPassData {
    //this index will let the SecondViewController know which row to delete with animation
    func onClickButton(index: Int)
}

//this class of cells is for the SecondViewController where users can see the clubs they subscribed and unsubscribe them if they want 
class SubscribedCells: UITableViewCell {
    
    var cellDelegate: TableViewPassData?
    
    var index: IndexPath?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var clubArray = [Club]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        loadItems()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }
    
    @IBOutlet weak var labelName: UILabel!
    
    @IBOutlet weak var buttonName: UIButton!
    
    @IBAction func subscribed(_ sender: UIButton) {
        //if the subscribed button is clicked, the button will turn into "unsubscribed"
        //the "subscribed" attribute of the club will also be updated to "false"
        //KEVIN, you can try to make these buttons look like stars. When the club is subscribed, the star will be blue, and when the club is unsubcribed, the star will turn gray
        buttonName.setTitle("Unsubscribed", for: .normal)
        for club in clubArray {
            if club.title == labelName.text {
                club.subscribed = false
                saveContext()
            }
        }
        //this will send data and tell SecondViewController to delete the row at which a club is unsubscribed.
        cellDelegate?.onClickButton(index: index!.row)
    }
    
    //load items from core data
    func loadItems() {
        let request : NSFetchRequest<Club> = Club.fetchRequest()
        do {
            clubArray = try context.fetch(request)
        } catch {
            print("error fetching data from context \(error)")
        }
    }
    
    //save items / update to core data
    func saveContext() {
        do {
            try context.save()
        } catch {
            print("error saving context \(error)")
        }
    }
    
}
