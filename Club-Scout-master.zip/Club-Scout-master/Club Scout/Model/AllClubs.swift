//
//  AllClubs.swift
//  Club Scout
//
//  Created by cate on 4/16/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData //The entity used is "Club"

//this class of cells is for the SecondSecondViewController where users have access to all the clubs. They can subscribe or unsubscribe.
class AllClubs: UITableViewCell {
    
    var index: IndexPath?
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var clubArray = [Club]()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        loadItems()
    }
    
    @IBOutlet weak var clubName: UILabel!
    
    @IBOutlet weak var buttonName: UIButton!
    
    //subscribe or unsubscribe a club and save this information to core data when button is pressed.
    //KEVIN, you can try to make these buttons look like stars. When the club is subscribed, the star will be blue, and when the club is unsubcribed, the star will turn gray
    @IBAction func subUnsub(_ sender: Any) {
        if clubArray[(index?.row)!].subscribed == false {
            clubArray[(index?.row)!].subscribed = true
            buttonName.setTitle("Subscribed", for: .normal)
        } else {
            clubArray[(index?.row)!].subscribed = false
            buttonName.setTitle("Unsubscribed", for: .normal)
        }
        saveContext()
    }

    //load items from core data
    func loadItems() {
        let request : NSFetchRequest<Club> = Club.fetchRequest()
        do {
            clubArray = try context.fetch(request)
        } catch {
            print("error fetching data from context \(error)")
        }
    }
    
    //save items / update to core data
    func saveContext() {
        do {
            try context.save()
        } catch {
            print("error saving context \(error)")
        }
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        //animate the button when it's tapped
        super.setSelected(selected, animated: animated)
    }
    
}
