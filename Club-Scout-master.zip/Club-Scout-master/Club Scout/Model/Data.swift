//
//  Data.swift
//  Club Scout
//
//  Created by cate on 5/17/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData

//pull data from core data and make a struct of data here.


