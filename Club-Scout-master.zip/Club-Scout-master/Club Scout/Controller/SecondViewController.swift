//
//  SecondViewController.swift
//  Club Scout
//
//  Created by cate on 4/2/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData //entity used is "Club"

//this TableViewController is for users to see which clubs they are subscribed to
class SecondViewController: UITableViewController {
 
    var clubArray = [Club]()
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
 
    override func viewDidLoad() {
        super.viewDidLoad()
        loadItems()
    }
    
    var array : [String?] = []
    
    //update view
    override func viewWillAppear(_ animated: Bool) {
        loadItems()
        tableView.reloadData()
        for club in clubArray {
            if club.subscribed == true {
                array.append(club.title)
            }
        }
    }
    
    //load items from core data
    func loadItems() {
        let request : NSFetchRequest<Club> = Club.fetchRequest()
        do {
            clubArray = try context.fetch(request)
        } catch {
            print("error fetching data from context \(error)")
        }
    }
    
    @IBOutlet weak var clubsTableView: UITableView!
    
    var selectedClubs : [String] = []
    
    //return the number of subscribed clubs for the number of rows
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var count = 0
        for club in clubArray {
            if club.subscribed == true {
                count += 1
            }
        }
        print("count is \(count)")
        return(count)
    }
    
    //The button "view all clubs" is inside the last table cell, so a counter is needed to tell if user has clicked on "view all clubs"
    var count = 0
    
    //display cells
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? SubscribedCells
        cell?.cellDelegate = self
        cell?.labelName.text = array[count]
        cell?.buttonName.setTitle("Subscribed", for: .normal)
        cell?.index = indexPath
        count += 1
        return cell!
    }
 
    //if user clicks on "view all clubs", the SecondView will segue into SecondSecondViewController
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        var count = 0
        for club in clubArray {
            if club.subscribed == true {
                count += 1
            }
        }
        if indexPath.row == count {
            performSegue(withIdentifier: "sendDataForwards", sender: self)
        }
    }

    //prepare for segue if "view all clubs" is tapped
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "sendDataForwards" {
            let SecondSecondVC = segue.destination as! SecondSecondViewController
            SecondSecondVC.data = selectedClubs
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

//receive data from SubscribedCell model
extension SecondViewController: TableViewPassData {
    
    func onClickButton(index: Int) {
        self.tableView.deleteRows(at: [IndexPath(row: index, section: 0)], with: .automatic)
    }
    
}

