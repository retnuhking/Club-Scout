//
//  FirstViewControllerNew.swift
//  Club Scout
//
//  Created by cate on 5/15/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData

class FirstViewControllerNew: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        loadItems()
    }
    
    //reference: Angela
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var clubArray = [Club]()
    
    //save items / update to core data
    func saveContext() {
        do {
            try context.save()
        } catch {
            print("error saving context \(error)")
        }
    }
    
    //load items from core data
    func loadItems() {
        let request : NSFetchRequest<Club> = Club.fetchRequest()
        do {
            clubArray = try context.fetch(request)
        } catch {
            print("error fetching data from context \(error)")
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        loadItems()
        tableView.reloadData()
    }
    
    //The event will show up if the club is in user's subscription list and the event is posted within a month.
    override func numberOfSections(in tableView: UITableView) -> Int {
        var count = 0
        //getting the current month
        let now = Date()
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMM"
        let month = dateFormatter.string(from: now)
        for club in clubArray {
            if club.subscribed == true {
                if club.post_when?.isEmpty == false {
                    if club.post_when!.contains(month) {
                        count += 1
                    }
                }
            }
        }
        print(count)
        return count
    }

    //return number of rows in section. Checking if the item is empty is necessary because club head might not fill out all the fields
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        /*
        var count = 0
        for club in clubArray {
            if club.post_dscrptn?.isEmpty == false  {
                count += 1
            }
            if club.post_location?.isEmpty == false {
                count += 1
            }
            if club.post_when?.isEmpty == false {
                count += 1
            }
        }
        count += 1
        print("Number of rows in section is \(count)")
 */
        return 4
    }
    
    //reference: https://www.youtube.com/watch?v=ClrSpJ3txAs
    //Build sections and cells below each section.
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") else {return UITableViewCell()}
            //section name will be the club name
            var array : [String] = []
            for club in clubArray {
                if club.subscribed == true && club.title == club.post_name {
                    array.append(club.title!)
                }
            }
            cell.textLabel?.text = array[indexPath.section]
            cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 21.0)
            
            return cell
        } else {
            guard let cell = tableView.dequeueReusableCell(withIdentifier: "cell") else {return UITableViewCell()}
            //each row in section should display each of the three items in the array.
            //right now there's an ERROR. all club events show the same thing.
            for club in clubArray {
                var array : [String] = []
                if club.subscribed == true && club.title == club.post_name {
                    array.append(club.post_dscrptn!)
                    array.append(club.post_location!)
                    array.append(club.post_when!)
                    print(array)
                    print("Index Path is \(indexPath.row)")
                    cell.textLabel?.text = array[indexPath.row - 1]
                }
            }
            return cell
        }
    }
    
    //KEVIN, if you have time, reference this https://www.youtube.com/watch?v=ClrSpJ3txAs to get expandable cells.
    
}
