//
//  FirstSecondViewController.swift
//  Club Scout
//
//  Created by cate on 4/27/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import CoreData //entity used is "Club"
import Alamofire

//this ViewController is for certified club heads to post events 
class FirstSecondViewController: UIViewController {
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    var clubArray = [Club]()
    
    @IBOutlet weak var clubName: UITextField!
    @IBOutlet weak var mtngDescription: UITextField!
    @IBOutlet weak var location: UITextField!
    @IBOutlet weak var date: UITextField!
    
    @IBOutlet weak var datePicker: UIDatePicker!
    @IBOutlet weak var setTimeButton: UIButton!
    
    var club = Club()
    
    //setting up default view
    override func viewDidLoad() {
        super.viewDidLoad()
        loadItems()
        datePicker.isHidden = true
        setTimeButton.isHidden = true
        clubName.placeholder = "Club Name"
        mtngDescription.placeholder = "Meeting description"
        location.placeholder = "Location"
        date.placeholder = "Time"
    }
    
    //show datePicker and setTimeButton when user taps on dateTextField
    @IBAction func dateTextField(_ sender: UITextField) {
        datePicker.isHidden = false
        setTimeButton.isHidden = false
    }
    
    //format time into string and display it in the textField. Hide datePicker and setTimeButton
    @IBAction func confirmTime(_ sender: UIButton) {

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE MMM d yyyy hh:mm "
        
        date.text = dateFormatter.string(from: datePicker.date)
        
        datePicker.isHidden = true
        setTimeButton.isHidden = true
         dismissKeyboard()
    }
    func dismissKeyboard() {
        view.endEditing(true)
    }
    //save items / update to core data
    func saveContext() {
        do {
            try context.save()
        } catch {
            print("error saving context \(error)")
        }
    }
    
    //load items from core data
    func loadItems() {
        let request : NSFetchRequest<Club> = Club.fetchRequest()
        do {
            clubArray = try context.fetch(request)
        } catch {
            print("error fetching data from context \(error)")
        }
    }
    
    //send user inupt data to Josh Park's online database
    @IBAction func uploadToCloud(_ sender: UIButton) {
        //Using CoreData to fake online database for demonstration purposes.
        
        //saving user input to core data
        for club in clubArray {
            if club.title == clubName.text {
                club.post_dscrptn = mtngDescription.text
                club.post_name = clubName.text
                club.post_location = location.text
                club.post_when = date.text
                club.post_mtgnum += 1
                saveContext()
            }
        }
            //clear textFields
        clubName.text = ""
        mtngDescription.text = ""
        location.text = ""
        date.text = ""
        
        
        
        let thatClub = clubName.text!
        print(thatClub)
        
        //this is when i create stuf
        Alamofire.request("http://172.17.5.52:8000/api/create/club_scout/" + "{\"testingName\": \"\(thatClub)\"}".addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!).responseString { response in
            print(response.result.value)
            
            //this is when i request data
            Alamofire.request("http://172.17.5.52:8000/api/request/club_scout/" + "{}".addingPercentEncoding(withAllowedCharacters: .urlHostAllowed)!).responseString { response in
                print(response.result.value)
            }
        }
 
        
    }
    
    
    
    
    /*
    @objc func dateChanged(datePicker: UIDatePicker) {
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "EEE MMM d yyyy hh:mm"
        view.endEditing(true)
        
        date.text = dateFormatter.string(from: datePicker.date)
        //club.post_when = dateFormatter.string(from: datePicker.date)
    }
 */
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
