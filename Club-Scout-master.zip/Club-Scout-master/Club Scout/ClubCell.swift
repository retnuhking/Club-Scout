//
//  ClubCell.swift
//  Club Scout
//
//  Created by cate on 4/11/19.
//  Copyright © 2019 Sean Zhan. All rights reserved.
//

import UIKit
import Foundation

class ClubCell: UITableViewCell {
    
    
    /*
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        let starButton = UIButton(type: .system)
        starButton.setImage(#imageLiteral(resourceName: "fav_star"), for: .normal)
        starButton.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        starButton.addTarget(self, action: #selector(handleMarkAsFavorite), for: .touchUpInside)
        accessoryView = starButton
    }
    
    @objc func handleMarkAsFavorite() {
        print("selected")
        //link?.linkStarToCell(cell: self)
        SecondViewController().linkStarToCell(cell: self)
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    */
    
}
